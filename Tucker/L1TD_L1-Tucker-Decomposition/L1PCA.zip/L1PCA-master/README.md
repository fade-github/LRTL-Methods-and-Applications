# L1PCA
Python module for L1-norm Principal Component Analysis
